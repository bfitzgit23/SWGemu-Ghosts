
wampa_bones = {
	minimumLevel = 0,
	maximumLevel = -1,
	customObjectName = "",
	directObjectTemplate = "object/tangible/component/weapon/wampa_bone_reinforcement_core.iff",
	craftingValues = {
		{"mindamage",54,100},
		{"maxdamage",54,100},
		{"useCount",1,6,0},
		{"attackspeed",0,0,0,0},
		{"woundchance",0,0,0,0},
		{"hitpoints",0,0,0,0},
		{"zerorangemod",0,0,0,0},
		{"maxrangemod",0,0,0,0},
		{"midrangemod",0,0,0,0},
		{"attackhealthcost",0,0,0,0},
		{"attackactioncost",0,0,0,0},
		{"attackmindcost",0,0,0,0},
	},
	customizationStringNames = {},
	customizationValues = {}
}

addLootItemTemplate("wampa_bones", wampa_bones)
