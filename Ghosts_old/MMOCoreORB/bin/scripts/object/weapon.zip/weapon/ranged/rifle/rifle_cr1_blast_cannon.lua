--Copyright (C) 2010 <SWGEmu>


--This File is part of Core3.

--This program is free software; you can redistribute 
--it and/or modify it under the terms of the GNU Lesser 
--General Public License as published by the Free Software
--Foundation; either version 2 of the License, 
--or (at your option) any later version.

--This program is distributed in the hope that it will be useful, 
--but WITHOUT ANY WARRANTY; without even the implied warranty of 
--MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
--See the GNU Lesser General Public License for
--more details.

--You should have received a copy of the GNU Lesser General 
--Public License along with this program; if not, write to
--the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

--Linking Engine3 statically or dynamically with other modules 
--is making a combined work based on Engine3. 
--Thus, the terms and conditions of the GNU Lesser General Public License 
--cover the whole combination.

--In addition, as a special exception, the copyright holders of Engine3 
--give you permission to combine Engine3 program with free software 
--programs or libraries that are released under the GNU LGPL and with 
--code included in the standard release of Core3 under the GNU LGPL 
--license (or modified versions of such code, with unchanged license). 
--You may copy and distribute such a system following the terms of the 
--GNU LGPL for Engine3 and the licenses of the other code concerned, 
--provided that you include the source code of that other code when 
--and as the GNU LGPL requires distribution of source code.

--Note that people who make modified versions of Engine3 are not obligated 
--to grant this special exception for their modified versions; 
--it is their choice whether to do so. The GNU Lesser General Public License 
--gives permission to release a modified version without this exception; 
--this exception also makes it possible to release a modified version 


object_weapon_ranged_rifle_rifle_cr1_blast_cannon = object_weapon_ranged_rifle_shared_rifle_cr1_blast_cannon:new {
	
	playerRaces = { 	"object/creature/player/abyssin_male.iff",
		"object/creature/player/aqualish_female.iff", 
		"object/creature/player/aqualish_male.iff", 
		"object/creature/player/arcona_male.iff",
		"object/creature/player/bith_female.iff", 
		"object/creature/player/bith_male.iff", 
		"object/creature/player/bothan_female.iff", 
		"object/creature/player/bothan_male.iff", 
		"object/creature/player/chiss_female.iff", 
		"object/creature/player/chiss_male.iff", 
		"object/creature/player/devaronian_male.iff", 
		"object/creature/player/dug_male.iff",
		"object/creature/player/duros_male.iff",
		"object/creature/player/geonosian_male.iff",
		"object/creature/player/gotal_male.iff", 
		"object/creature/player/gran_male.iff", 
		"object/creature/player/human_female.iff", 
		"object/creature/player/human_male.iff", 
		"object/creature/player/hutt_female.iff", 
		"object/creature/player/hutt_male.iff", 
		"object/creature/player/ishi_tib_male.iff", 
		"object/creature/player/kel_dor_male.iff",
		"object/creature/player/kubaz_male.iff",
		"object/creature/player/moncal_female.iff", 
		"object/creature/player/moncal_male.iff", 
		"object/creature/player/nautolan_male.iff", 
		"object/creature/player/nightsister_female.iff",
		"object/creature/player/nikto_male.iff", 
		"object/creature/player/quarren_male.iff", 
		"object/creature/player/rodian_female.iff", 
		"object/creature/player/rodian_male.iff", 
		"object/creature/player/sanyassan_female.iff",
		"object/creature/player/sanyassan_male.iff",
		"object/creature/player/smc_female.iff", 
		"object/creature/player/sullustan_female.iff", 
		"object/creature/player/sullustan_male.iff", 
		"object/creature/player/togruta_female.iff", 
		"object/creature/player/twilek_female.iff", 
		"object/creature/player/twilek_male.iff", 
		"object/creature/player/weequay_male.iff", 
		"object/creature/player/zabrak_female.iff", 
		"object/creature/player/zabrak_male.iff", 
		"object/creature/player/wookiee_male.iff",
		"object/creature/player/wookiee_female.iff",
		"object/creature/player/talz_male.iff",
		"object/creature/player/ithorian_male.iff",
		"object/creature/player/general_grievous_male.iff"
 },

	-- RANGEDATTACK, MELEEATTACK, FORCEATTACK, TRAPATTACK, GRENADEATTACK, HEAVYACIDBEAMATTACK,
	-- HEAVYLIGHTNINGBEAMATTACK, HEAVYPARTICLEBEAMATTACK, HEAVYROCKETLAUNCHERATTACK, HEAVYLAUNCHERATTACK
	attackType = RANGEDATTACK,
	weaponType = SPECIALHEAVYWEAPON,

	-- ENERGY, KINETIC, ELECTRICITY, STUN, BLAST, HEAT, COLD, ACID, LIGHTSABER
	damageType = COLD,

	-- NONE, LIGHT, MEDIUM, HEAVY
	armorPiercing = LIGHT,

	-- combat_rangedspecialize_bactarifle, combat_rangedspecialize_rifle, combat_rangedspecialize_pistol, combat_rangedspecialize_heavy, combat_rangedspecialize_carbine
	-- combat_meleespecialize_unarmed, combat_meleespecialize_twohand, combat_meleespecialize_polearm, combat_meleespecialize_onehand, combat_general,
	-- combat_meleespecialize_twohandlightsaber, combat_meleespecialize_polearmlightsaber, combat_meleespecialize_onehandlightsaber
	xpType = "combat_rangedspecialize_heavy",

	-- See http://www.ocdsoft.com/files/certifications.xls
	certificationsRequired = { "cert_rifle_acid_beam" },
	-- See http://www.ocdsoft.com/files/accuracy.xls
	creatureAccuracyModifiers = { "heavy_rifle_acid_accuracy" },

	-- See http://www.ocdsoft.com/files/defense.xls
	defenderDefenseModifiers = { "ranged_defense" },

	-- Leave as "dodge" for now, may have additions later
	defenderSecondaryDefenseModifiers = { "block" },

	-- See http://www.ocdsoft.com/files/speed.xls
	speedModifiers = { "heavy_rifle_acid_speed" },

	-- Leave blank for now
	damageModifiers = {  },
		
	skillMods = {
			{"heavy_flame_thrower_accuracy", 25},
			{"heavy_flame_thrower_speed", 25}
				},


	-- The values below are the default values.  To be used for blue frog objects primarily
	healthAttackCost = 84,
	actionAttackCost = 20,
	mindAttackCost = 20,
	forceCost = 0,

	pointBlankAccuracy = 15,
	pointBlankRange = 0,

	idealRange = 50,
	idealAccuracy = -50,

	maxRange = 64,
	maxRangeAccuracy = 0,

	minDamage = 480,
	maxDamage = 830,

	attackSpeed = 3,

	woundsRatio = 12,

	numberExperimentalProperties = {1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2},
	experimentalProperties = {"XX", "XX", "CD", "OQ", "CD", "OQ", "CD", "OQ", "CD", "OQ", "CD", "OQ", "CD", "OQ", "CD", "OQ", "XX", "CD", "OQ", "CD", "OQ", "CD", "OQ", "CD", "OQ"},
	experimentalWeights = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
	experimentalGroupTitles = {"null", "null", "expDamage", "expDamage", "expDamage", "expDamage", "expEffeciency", "exp_durability", "expRange", "null", "expRange", "expEffeciency", "expEffeciency", "expEffeciency"},
	experimentalSubGroupTitles = {"null", "null", "mindamage", "maxdamage", "attackspeed", "woundchance", "roundsused", "hitpoints", "zerorangemod", "midrange", "midrangemod", "attackhealthcost", "attackactioncost", "attackmindcost"},
	experimentalMin = {0, 0, 240, 690, 7.2, 8, 30, 750, 10, 50, -65, 84, 20, 20},
	experimentalMax = {0, 0, 476, 826, 4.9, 16, 65, 1500, 20, 50, -35, 45, 10, 10},
	experimentalPrecision = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	experimentalCombineType = {0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
}


ObjectTemplates:addTemplate(object_weapon_ranged_rifle_rifle_cr1_blast_cannon, "object/weapon/ranged/rifle/rifle_cr1_blast_cannon.iff")
