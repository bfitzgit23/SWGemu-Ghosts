--Korriban Static Spawns
--This is to be used for static spawns that are NOT part of caves, cities, dungeons, poi's, or other large screenplays.
local ObjectManager = require("managers.object.object_manager")

KorribanStaticSpawnsScreenPlay = ScreenPlay:new {
	numberOfActs = 1,
	screenplayName = "KorribanStaticSpawnsScreenPlay",
}

registerScreenPlay("KorribanStaticSpawnsScreenPlay", true)

function KorribanStaticSpawnsScreenPlay:start()
	if (isZoneEnabled("korriban")) then
		self:spawnMobiles()
		self:spawnSceneObjects()
	end
end

function KorribanStaticSpawnsScreenPlay:spawnSceneObjects()
	-- Decorative objects for atmosphere
	
	-- Valley of the Dark Lords - Ancient statues and ruins
	spawnSceneObject("korriban", "object/static/structure/general/statue_imperial_soldier_hum_m.iff", -1346, 91, -830, 0, math.rad(0))
	spawnSceneObject("korriban", "object/static/structure/general/campfire_logs_burnt_small.iff", -1300, 91, -850, 0, math.rad(45))
	
	-- Archaeological Outpost - Equipment
	spawnSceneObject("korriban", "object/tangible/furniture/all/frn_all_toolchest_lg_s01.iff", -1712, 91, -679, 0, 0, 0, 1, 0)
	spawnSceneObject("korriban", "object/tangible/camp/camp_light_s2.iff", -1710, 91, -675, 0, 0, 0, 1, 0)
	spawnSceneObject("korriban", "object/tangible/camp/camp_stool_tall.iff", -1715, 91, -680, 0, 0, 0, 1, 0)
end

function KorribanStaticSpawnsScreenPlay:spawnMobiles()

	-- =====================================================
	-- VALLEY OF THE DARK LORDS (-1346, -830)
	-- Heavy concentration of Dark Jedi and Force users
	-- =====================================================
	
	-- Dark Jedi Masters (Boss-level)
	spawnMobile("korriban", "dark_jedi_master", 720, -1346, 91, -830, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_master", 720, -1320, 91, -850, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_master", 720, -1370, 91, -810, getRandomNumber(360), 0)
	
	-- Dark Jedi Knights (Mid-tier)
	spawnMobile("korriban", "dark_jedi_knight", 600, -1300, 91, -800, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_knight", 600, -1310, 91, -860, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_knight", 600, -1380, 91, -840, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_knight", 600, -1360, 91, -790, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_knight", 600, -1330, 91, -870, getRandomNumber(360), 0)
	
	-- Dark Jedi Sentinels (Guards)
	spawnMobile("korriban", "dark_jedi_sentinel", 480, -1290, 91, -820, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_sentinel", 480, -1350, 91, -780, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_sentinel", 480, -1390, 91, -820, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_sentinel", 480, -1320, 91, -890, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_sentinel_imperial", 480, -1400, 91, -850, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_sentinel_imperial", 480, -1280, 91, -810, getRandomNumber(360), 0)
	
	-- Force-sensitive NPCs (Lower tier)
	spawnMobile("korriban", "force_trained_archaist", 420, -1310, 91, -810, getRandomNumber(360), 0)
	spawnMobile("korriban", "force_trained_archaist", 420, -1370, 91, -860, getRandomNumber(360), 0)
	spawnMobile("korriban", "force_sensitive_crypt_crawler", 360, -1295, 91, -835, getRandomNumber(360), 0)
	spawnMobile("korriban", "force_sensitive_crypt_crawler", 360, -1385, 91, -815, getRandomNumber(360), 0)
	spawnMobile("korriban", "force_sensitive_renegade", 360, -1325, 91, -795, getRandomNumber(360), 0)
	spawnMobile("korriban", "force_sensitive_renegade", 360, -1355, 91, -875, getRandomNumber(360), 0)
	spawnMobile("korriban", "forsaken_force_drifter", 360, -1340, 91, -840, getRandomNumber(360), 0)
	spawnMobile("korriban", "forsaken_force_drifter", 360, -1360, 91, -820, getRandomNumber(360), 0)
	spawnMobile("korriban", "novice_force_mystic", 300, -1315, 91, -825, getRandomNumber(360), 0)
	spawnMobile("korriban", "novice_force_mystic", 300, -1375, 91, -835, getRandomNumber(360), 0)
	spawnMobile("korriban", "force_crystal_hunter", 360, -1350, 91, -800, getRandomNumber(360), 0)
	spawnMobile("korriban", "force_crystal_hunter", 360, -1330, 91, -850, getRandomNumber(360), 0)
	
	-- Deadly Korriban creatures
	spawnMobile("korriban", "terentatek", 600, -1305, 91, -845, getRandomNumber(360), 0)
	spawnMobile("korriban", "terentatek", 600, -1365, 91, -805, getRandomNumber(360), 0)
	spawnMobile("korriban", "hssiss", 480, -1335, 91, -815, getRandomNumber(360), 0)
	spawnMobile("korriban", "hssiss", 480, -1355, 91, -855, getRandomNumber(360), 0)
	
	-- =====================================================
	-- SHYRACK CAVE (457, -235)
	-- Cave creatures and some dark siders
	-- =====================================================
	
	spawnMobile("korriban", "shyrack", 300, 457, 91, -235, getRandomNumber(360), 0)
	spawnMobile("korriban", "shyrack", 300, getRandomNumber(10) + 450, 91, getRandomNumber(10) - 240, getRandomNumber(360), 0)
	spawnMobile("korriban", "shyrack", 300, getRandomNumber(10) + 450, 91, getRandomNumber(10) - 240, getRandomNumber(360), 0)
	spawnMobile("korriban", "shyrack", 300, getRandomNumber(10) + 450, 91, getRandomNumber(10) - 240, getRandomNumber(360), 0)
	spawnMobile("korriban", "shyrack", 300, getRandomNumber(10) + 450, 91, getRandomNumber(10) - 240, getRandomNumber(360), 0)
	
	spawnMobile("korriban", "klor_slug", 360, getRandomNumber(10) + 460, 91, getRandomNumber(10) - 230, getRandomNumber(360), 0)
	spawnMobile("korriban", "klor_slug", 360, getRandomNumber(10) + 460, 91, getRandomNumber(10) - 230, getRandomNumber(360), 0)
	spawnMobile("korriban", "klor_slug", 360, getRandomNumber(10) + 460, 91, getRandomNumber(10) - 230, getRandomNumber(360), 0)
	
	spawnMobile("korriban", "tukata", 420, getRandomNumber(10) + 455, 91, getRandomNumber(10) - 240, getRandomNumber(360), 0)
	spawnMobile("korriban", "tukata", 420, getRandomNumber(10) + 455, 91, getRandomNumber(10) - 240, getRandomNumber(360), 0)
	
	-- Cave explorer dark siders
	spawnMobile("korriban", "force_sensitive_crypt_crawler", 360, 465, 91, -228, getRandomNumber(360), 0)
	spawnMobile("korriban", "novice_force_mystic", 300, 452, 91, -242, getRandomNumber(360), 0)
	
	-- =====================================================
	-- ARCHAEOLOGICAL OUTPOST (-1712, -679)
	-- Scientists, droids, and some hostile force users
	-- =====================================================
	
	-- Friendly NPCs
	local pNpc = spawnMobile("korriban", "archaeologist_leader", 1, -1712, 91, -679, 0, 0)
	self:setMoodString(pNpc, "neutral")
	
	pNpc = spawnMobile("korriban", "reltha_aiden", 1, -1710, 91, -675, 45, 0)
	self:setMoodString(pNpc, "npc_use_terminal_high")
	
	pNpc = spawnMobile("korriban", "bex_delata", 1, -1708, 91, -682, -90, 0)
	self:setMoodString(pNpc, "worried")
	
	pNpc = spawnMobile("korriban", "omor_rikan", 1, -1715, 91, -677, 135, 0)
	self:setMoodString(pNpc, "conversation")
	
	pNpc = spawnMobile("korriban", "taelan_delar", 1, -1714, 91, -681, -45, 0)
	self:setMoodString(pNpc, "neutral")
	
	pNpc = spawnMobile("korriban", "bray_terex", 1, -1709, 91, -678, 90, 0)
	self:setMoodString(pNpc, "nervous")
	
	pNpc = spawnMobile("korriban", "moraband_bunker_protocol_droid", 1, -1716, 91, -680, 180, 0)
	self:setMoodString(pNpc, "neutral")
	
	-- Hostile force users nearby
	spawnMobile("korriban", "force_sensitive_renegade", 360, -1700, 91, -665, getRandomNumber(360), 0)
	spawnMobile("korriban", "forsaken_force_drifter", 360, -1725, 91, -690, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_sentinel", 480, -1720, 91, -670, getRandomNumber(360), 0)
	
	-- =====================================================
	-- DRESHDAE VALLEY (1060, -5332)
	-- Town area with mixed NPCs and some creatures
	-- =====================================================
	
	spawnMobile("korriban", "force_crystal_hunter", 360, 1055, 91, -5330, getRandomNumber(360), 0)
	spawnMobile("korriban", "novice_force_mystic", 300, 1065, 91, -5335, getRandomNumber(360), 0)
	
	-- Creatures around town outskirts
	spawnMobile("korriban", "tukata", 420, getRandomNumber(20) + 1080, 91, getRandomNumber(20) - 5350, getRandomNumber(360), 0)
	spawnMobile("korriban", "tukata", 420, getRandomNumber(20) + 1080, 91, getRandomNumber(20) - 5350, getRandomNumber(360), 0)
	spawnMobile("korriban", "tukata", 420, getRandomNumber(20) + 1080, 91, getRandomNumber(20) - 5350, getRandomNumber(360), 0)
	
	spawnMobile("korriban", "hssiss", 480, getRandomNumber(20) + 1040, 91, getRandomNumber(20) - 5310, getRandomNumber(360), 0)
	spawnMobile("korriban", "hssiss", 480, getRandomNumber(20) + 1040, 91, getRandomNumber(20) - 5310, getRandomNumber(360), 0)
	
	-- =====================================================
	-- RANDOM WILDERNESS SPAWNS
	-- Scattered creatures across the planet
	-- =====================================================
	
	-- Terentateks (rare, dangerous)
	spawnMobile("korriban", "terentatek", 600, getRandomNumber(200) - 1500, 91, getRandomNumber(200) - 1000, getRandomNumber(360), 0)
	spawnMobile("korriban", "terentatek", 600, getRandomNumber(200) + 500, 91, getRandomNumber(200) - 500, getRandomNumber(360), 0)
	
	-- Hssiss packs
	spawnMobile("korriban", "hssiss", 480, getRandomNumber(200) - 800, 91, getRandomNumber(200) - 600, getRandomNumber(360), 0)
	spawnMobile("korriban", "hssiss", 480, getRandomNumber(200) - 800, 91, getRandomNumber(200) - 600, getRandomNumber(360), 0)
	spawnMobile("korriban", "hssiss", 480, getRandomNumber(200) - 800, 91, getRandomNumber(200) - 600, getRandomNumber(360), 0)
	
	-- Tukata packs (most common)
	spawnMobile("korriban", "tukata", 420, getRandomNumber(300) - 500, 91, getRandomNumber(300) - 1200, getRandomNumber(360), 0)
	spawnMobile("korriban", "tukata", 420, getRandomNumber(300) - 500, 91, getRandomNumber(300) - 1200, getRandomNumber(360), 0)
	spawnMobile("korriban", "tukata", 420, getRandomNumber(300) + 800, 91, getRandomNumber(300) - 400, getRandomNumber(360), 0)
	spawnMobile("korriban", "tukata", 420, getRandomNumber(300) + 800, 91, getRandomNumber(300) - 400, getRandomNumber(360), 0)
	
	-- Klor slugs
	spawnMobile("korriban", "klor_slug", 360, getRandomNumber(200) + 200, 91, getRandomNumber(200) - 800, getRandomNumber(360), 0)
	spawnMobile("korriban", "klor_slug", 360, getRandomNumber(200) - 1000, 91, getRandomNumber(200) - 400, getRandomNumber(360), 0)
	
	-- Wandering Dark Jedi
	spawnMobile("korriban", "dark_jedi_knight", 600, getRandomNumber(300) - 600, 91, getRandomNumber(300) - 1000, getRandomNumber(360), 0)
	spawnMobile("korriban", "dark_jedi_sentinel", 480, getRandomNumber(300) + 600, 91, getRandomNumber(300) - 600, getRandomNumber(360), 0)
	spawnMobile("korriban", "force_trained_archaist", 420, getRandomNumber(300) - 900, 91, getRandomNumber(300) - 700, getRandomNumber(360), 0)

end
